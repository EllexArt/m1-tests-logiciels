package fr.rouen.mastergil.tptest;

public enum Devise {
    DOLLAR,
    EURO,
    LIVRE,
    YEN,
    PESO,
    DINAR
}
